<?php
require_once '../config.php';
requireLogin(); requireAdmin();
$db=getDB();
if(isset($_GET['verify'])){$db->prepare("UPDATE users SET is_verified=1 WHERE id=?")->execute([(int)$_GET['verify']]);flash('success','User verified.');header('Location: index.php');exit;}
if(isset($_GET['del'])){$db->prepare("DELETE FROM users WHERE id!=1 AND id=?")->execute([(int)$_GET['del']]);flash('success','User deleted.');header('Location: index.php');exit;}
$users=$db->query("SELECT u.*,(SELECT COUNT(*) FROM tasks WHERE user_id=u.id)tc,(SELECT COUNT(*) FROM expenses WHERE user_id=u.id)ec,(SELECT COUNT(*) FROM dues WHERE user_id=u.id)dc FROM users u ORDER BY created_at DESC")->fetchAll();
$logs=$db->query("SELECT n.*,u.name,u.email FROM notifications n JOIN users u ON n.user_id=u.id ORDER BY n.sent_at DESC LIMIT 50")->fetchAll();
$flash=getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin — TaskFlow Pro</title>
<link rel="stylesheet" href="../css/style.css"></head>
<body>
<nav class="navbar">
  <div class="nav-brand"><a href="../pages/dashboard.php"><div class="logo-sm">TF</div><span>Admin Panel</span></a></div>
  <div class="nav-links"><a href="../pages/dashboard.php">← App</a></div>
  <div class="nav-user"><a href="../logout.php" class="btn btn-d btn-sm">Logout</a></div>
</nav>
<div class="container">
  <?php if($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
  <div class="page-header"><h2>⚙️ Admin Panel</h2></div>
  <div class="card">
    <div class="card-header"><h3>👥 Users (<?= count($users) ?>)</h3></div>
    <div style="overflow:auto">
    <table class="table">
      <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Verified</th><th>Currency</th><th>Tasks</th><th>Exp</th><th>Dues</th><th>Joined</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach($users as $u): ?>
      <tr>
        <td><strong><?= e($u['name']) ?></strong></td>
        <td><?= e($u['email']) ?></td>
        <td><span class="badge <?= $u['role']==='admin'?'b-high':'b-med' ?>"><?= $u['role'] ?></span></td>
        <td><?= $u['is_verified']?'<span class="tc">✅</span>':'<span class="td">❌</span>' ?></td>
        <td><?= e($u['currency_symbol'].$u['currency']) ?></td>
        <td><?= $u['tc'] ?></td><td><?= $u['ec'] ?></td><td><?= $u['dc'] ?></td>
        <td class="tm"><?= date('d M Y',strtotime($u['created_at'])) ?></td>
        <td>
          <?php if(!$u['is_verified']): ?><a href="index.php?verify=<?= $u['id'] ?>" class="btn btn-p btn-sm">Verify</a><?php endif; ?>
          <?php if($u['id']!=1): ?><a href="index.php?del=<?= $u['id'] ?>" class="btn btn-d btn-sm" onclick="return confirm('Delete user?')">🗑️</a><?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div class="card" style="margin-top:1.1rem">
    <div class="card-header"><h3>📬 Notification Logs</h3></div>
    <div style="overflow:auto">
    <table class="table">
      <thead><tr><th>User</th><th>Type</th><th>Channel</th><th>Message</th><th>Status</th><th>Time</th></tr></thead>
      <tbody>
      <?php foreach($logs as $n): ?>
      <tr>
        <td><?= e($n['name']) ?></td>
        <td><span class="badge b-med"><?= $n['type'] ?></span></td>
        <td><?= $n['channel']==='email'?'📧':($n['channel']==='whatsapp'?'📱':'🔔') ?> <?= $n['channel'] ?></td>
        <td><?= e($n['message']) ?></td>
        <td><span class="badge <?= $n['status']==='sent'?'b-ok':'b-ng' ?>"><?= $n['status'] ?></span></td>
        <td class="tm"><?= date('d M H:i',strtotime($n['sent_at'])) ?></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</div>
</body></html>
