<?php
require_once '../config.php';
if (!isLoggedIn()) { http_response_code(401); exit; }
$body = file_get_contents('php://input');
if ($body) {
    getDB()->prepare("UPDATE users SET push_subscription=? WHERE id=?")->execute([$body, uid()]);
    echo json_encode(['ok'=>true]);
}
