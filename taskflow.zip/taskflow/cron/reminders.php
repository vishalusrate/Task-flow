<?php
// cron/reminders.php
// Crontab madhe add kara:
// 0 * * * * php /var/www/html/taskflow/cron/reminders.php
// Browser madhe test: http://localhost/taskflow/cron/reminders.php

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/mailer.php';
require_once __DIR__ . '/../includes/notifier.php';

$db = getDB();
echo "[".date('Y-m-d H:i:s')."] Cron started\n";

// 1. RECURRING TASKS — auto reopen
$rec=$db->prepare("SELECT t.* FROM tasks t WHERE t.recurring_type!='none' AND t.recurring_type IS NOT NULL AND t.status='completed' AND t.due_date IS NOT NULL AND NOT EXISTS(SELECT 1 FROM tasks t2 WHERE t2.user_id=t.user_id AND t2.title=t.title AND t2.recurring_type=t.recurring_type AND t2.status!='completed' AND t2.due_date>t.due_date)");
$rec->execute(); $recs=$rec->fetchAll();
foreach ($recs as $t) {
    $next=match($t['recurring_type']){'daily'=>date('Y-m-d',strtotime($t['due_date'].' +1 day')),'weekly'=>date('Y-m-d',strtotime($t['due_date'].' +1 week')),'monthly'=>date('Y-m-d',strtotime($t['due_date'].' +1 month')),default=>null};
    if(!$next) continue;
    $chk=$db->prepare("SELECT id FROM tasks WHERE user_id=? AND title=? AND due_date=? AND status!='completed'");$chk->execute([$t['user_id'],$t['title'],$next]);
    if($chk->fetch()) continue;
    $db->prepare("INSERT INTO tasks(user_id,title,description,priority,status,due_date,due_time,cc_emails,whatsapp_reminder,email_reminder,push_reminder,recurring_type,recurring_parent_id) VALUES(?,?,?,?,'pending',?,?,?,?,?,?,?,?)")
       ->execute([$t['user_id'],$t['title'],$t['description'],$t['priority'],$next,$t['due_time'],$t['cc_emails'],$t['whatsapp_reminder'],$t['email_reminder'],$t['push_reminder'],$t['recurring_type'],$t['recurring_parent_id']?:$t['id']]);
    echo "  🔁 Recurring created: '{$t['title']}' → $next\n";
}

// 2. TASK REMINDERS — due within 24 hours
$ts=$db->prepare("SELECT t.*,u.name un,u.email,u.whatsapp,u.push_subscription,u.currency_symbol FROM tasks t JOIN users u ON t.user_id=u.id WHERE t.status!='completed' AND t.due_date IS NOT NULL AND t.due_date BETWEEN CURDATE() AND DATE_ADD(NOW(),INTERVAL 24 HOUR) AND t.reminder_sent=0");
$ts->execute();
foreach ($ts->fetchAll() as $t) {
    $u=['name'=>$t['un'],'email'=>$t['email'],'whatsapp'=>$t['whatsapp'],'push_subscription'=>$t['push_subscription'],'currency_symbol'=>$t['currency_symbol']];
    if($t['email_reminder']){$ok=sendTaskReminderEmail($u,$t);echo "  Email task#{$t['id']}: ".($ok?'✓':'✗')."\n";}
    if($t['whatsapp_reminder']){$ok=sendTaskWhatsApp($u,$t);echo "  WA task#{$t['id']}: ".($ok?'✓':'✗')."\n";}
    if($t['push_reminder']){sendTaskPush($u,$t);}
    $db->prepare("UPDATE tasks SET reminder_sent=1 WHERE id=?")->execute([$t['id']]);
}

// 3. DUE REMINDERS — due within 72 hours
$ds=$db->prepare("SELECT d.*,u.name un,u.email,u.whatsapp,u.push_subscription,u.currency_symbol FROM dues d JOIN users u ON d.user_id=u.id WHERE d.status!='paid' AND d.due_date IS NOT NULL AND d.due_date BETWEEN CURDATE() AND DATE_ADD(NOW(),INTERVAL 72 HOUR) AND (d.reminder_sent_at IS NULL OR d.reminder_sent_at<DATE_SUB(NOW(),INTERVAL 24 HOUR))");
$ds->execute();
foreach ($ds->fetchAll() as $d) {
    $u=['name'=>$d['un'],'email'=>$d['email'],'whatsapp'=>$d['whatsapp'],'push_subscription'=>$d['push_subscription'],'currency_symbol'=>$d['currency_symbol']];
    if($d['email_reminder']){sendDueReminderEmail($u,$d);}
    if($d['whatsapp_reminder']){sendDueWhatsApp($u,$d);if($d['due_type']==='given')sendDueWhatsAppToPerson($d,$d['un']);}
    if($d['push_reminder']){sendDuePush($u,$d);}
    $db->prepare("UPDATE dues SET reminder_sent_at=NOW() WHERE id=?")->execute([$d['id']]);
    echo "  Due#{$d['id']} reminders sent\n";
}

echo "[".date('Y-m-d H:i:s')."] Cron done\n";
