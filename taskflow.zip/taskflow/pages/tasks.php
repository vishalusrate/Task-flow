<?php
require_once '../config.php';
requireLogin();
$db  = getDB();
$uid = uid();

function makeNext(PDO $db, array $t): void {
    if (empty($t['recurring_type']) || $t['recurring_type']==='none') return;
    $next = match($t['recurring_type']) {
        'daily'   => date('Y-m-d', strtotime(($t['due_date']??date('Y-m-d')).' +1 day')),
        'weekly'  => date('Y-m-d', strtotime(($t['due_date']??date('Y-m-d')).' +1 week')),
        'monthly' => date('Y-m-d', strtotime(($t['due_date']??date('Y-m-d')).' +1 month')),
        default   => null,
    };
    if (!$next) return;
    $chk=$db->prepare("SELECT id FROM tasks WHERE user_id=? AND title=? AND due_date=? AND status!='completed'");
    $chk->execute([$t['user_id'],$t['title'],$next]);
    if ($chk->fetch()) return;
    $db->prepare("INSERT INTO tasks (user_id,title,description,priority,status,due_date,due_time,cc_emails,
        whatsapp_reminder,email_reminder,push_reminder,recurring_type,recurring_parent_id)
        VALUES(?,?,?,?,'pending',?,?,?,?,?,?,?,?)")
       ->execute([$t['user_id'],$t['title'],$t['description'],$t['priority'],$next,
                  $t['due_time'],$t['cc_emails'],$t['whatsapp_reminder'],$t['email_reminder'],
                  $t['push_reminder'],$t['recurring_type'],$t['recurring_parent_id']?:$t['id']]);
}

// DELETE
if (isset($_GET['delete'])) {
    verifyCsrf();
    $tid = (int)$_GET['delete'];
    if (isset($_GET['all'])) {
        $r=$db->prepare("SELECT recurring_parent_id FROM tasks WHERE id=? AND user_id=?");
        $r->execute([$tid,$uid]); $row=$r->fetch(); $pid=$row['recurring_parent_id']?:$tid;
        $db->prepare("DELETE FROM tasks WHERE user_id=? AND (id=? OR recurring_parent_id=?)")->execute([$uid,$pid,$pid]);
        flash('success','Poori recurring series delete jhali.');
    } else {
        $db->prepare("DELETE FROM tasks WHERE id=? AND user_id=?")->execute([$tid,$uid]);
        flash('success','Task deleted.');
    }
    header('Location: tasks.php'); exit;
}

// QUICK COMPLETE
if (isset($_GET['done'])) {
    verifyCsrf();
    $tid=(int)$_GET['done'];
    $s=$db->prepare("SELECT * FROM tasks WHERE id=? AND user_id=?");
    $s->execute([$tid,$uid]); $t=$s->fetch();
    if ($t) {
        $db->prepare("UPDATE tasks SET status='completed',updated_at=NOW() WHERE id=?")->execute([$tid]);
        $isRec=!empty($t['recurring_type'])&&$t['recurring_type']!=='none';
        if ($isRec) { makeNext($db,$t); flash('success','✅ Complete! Next '.$t['recurring_type'].' task auto-create jhala 🔁'); }
        else flash('success','✅ Task complete!');
    }
    header('Location: tasks.php'); exit;
}

// SAVE
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verifyCsrf();
    $id  =(int)($_POST['id']??0);
    $tit =sanitize($_POST['title']??'');
    $dsc =sanitize($_POST['description']??'');
    $pri =in_array($_POST['priority'],['low','medium','high'])?$_POST['priority']:'medium';
    $sta =in_array($_POST['status'],['pending','in_progress','completed'])?$_POST['status']:'pending';
    $dd  =$_POST['due_date']?:null;
    $dt  =$_POST['due_time']?:null;
    $cc  =sanitize($_POST['cc_emails']??'');
    $wr  =isset($_POST['wr'])?1:0;
    $er  =isset($_POST['er'])?1:0;
    $pr  =isset($_POST['pr'])?1:0;
    $rec =in_array($_POST['rec']??'none',['none','daily','weekly','monthly'])?$_POST['rec']:'none';

    if (!$tit) { $error='Title required ahe.'; }
    elseif ($id) {
        $old=$db->prepare("SELECT * FROM tasks WHERE id=? AND user_id=?");
        $old->execute([$id,$uid]); $ot=$old->fetch();
        $db->prepare("UPDATE tasks SET title=?,description=?,priority=?,status=?,due_date=?,due_time=?,
            cc_emails=?,whatsapp_reminder=?,email_reminder=?,push_reminder=?,recurring_type=?,
            reminder_sent=0,updated_at=NOW() WHERE id=? AND user_id=?")
           ->execute([$tit,$dsc,$pri,$sta,$dd,$dt,$cc,$wr,$er,$pr,$rec,$id,$uid]);
        if ($sta==='completed'&&($ot['status']??'')!=='completed'&&$rec!=='none') {
            makeNext($db,array_merge($ot,['status'=>'completed','due_date'=>$dd,'recurring_type'=>$rec,
                'title'=>$tit,'description'=>$dsc,'priority'=>$pri,'cc_emails'=>$cc,
                'whatsapp_reminder'=>$wr,'email_reminder'=>$er,'push_reminder'=>$pr]));
            flash('success','✅ Updated! Next '.$rec.' occurrence scheduled 🔁');
        } else { flash('success','Task updated!'); }
        header('Location: tasks.php'); exit;
    } else {
        $db->prepare("INSERT INTO tasks (user_id,title,description,priority,status,due_date,due_time,cc_emails,
            whatsapp_reminder,email_reminder,push_reminder,recurring_type) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$uid,$tit,$dsc,$pri,$sta,$dd,$dt,$cc,$wr,$er,$pr,$rec]);
        flash('success','Task added!'); header('Location: tasks.php'); exit;
    }
}

$editTask=null;
if (isset($_GET['edit'])) {
    $s=$db->prepare("SELECT * FROM tasks WHERE id=? AND user_id=?");
    $s->execute([(int)$_GET['edit'],$uid]); $editTask=$s->fetch();
}

$fs=$_GET['status']??''; $fp=$_GET['priority']??''; $fr=$_GET['rec']??''; $sq=sanitize($_GET['q']??'');
$wh="user_id=?"; $pa=[$uid];
if($fs){$wh.=" AND status=?";$pa[]=$fs;}
if($fp){$wh.=" AND priority=?";$pa[]=$fp;}
if($fr){$wh.=" AND recurring_type=?";$pa[]=$fr;}
if($sq){$wh.=" AND title LIKE ?";$pa[]='%'.$sq.'%';}

$stmt=$db->prepare("SELECT * FROM tasks WHERE $wh ORDER BY FIELD(status,'in_progress','pending','completed'),FIELD(priority,'high','medium','low'),due_date ASC");
$stmt->execute($pa); $tasks=$stmt->fetchAll();

$ri=['none'=>'','daily'=>'🔁','weekly'=>'📅','monthly'=>'🗓️'];
$rl=['none'=>'No Repeat','daily'=>'Daily','weekly'=>'Weekly','monthly'=>'Monthly'];
$flash=getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Tasks — TaskFlow Pro</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'partials/navbar.php'; ?>
<div class="container">
  <?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
  <?php if (!empty($error)): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <div class="page-header">
    <h2>📋 Tasks</h2>
    <button class="btn btn-p" onclick="tf()">+ Add Task</button>
  </div>

  <!-- FORM -->
  <div class="card form-card <?= ($editTask||!empty($error))?'':'hidden' ?>" id="tForm">
    <h3><?= $editTask?'✏️ Edit Task':'➕ New Task' ?></h3>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <?php if ($editTask): ?><input type="hidden" name="id" value="<?= $editTask['id'] ?>"><?php endif; ?>
      <div class="form-row">
        <div class="form-group" style="flex:2">
          <label>Title *</label>
          <input type="text" name="title" value="<?= e($editTask['title']??'') ?>" placeholder="Kaay kraycha ahe?" required>
        </div>
        <div class="form-group">
          <label>Priority</label>
          <select name="priority">
            <?php foreach(['low','medium','high'] as $p): ?>
            <option value="<?= $p ?>" <?= ($editTask['priority']??'medium')===$p?'selected':'' ?>><?= ucfirst($p) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label>Status</label>
          <select name="status">
            <?php foreach(['pending','in_progress','completed'] as $s): ?>
            <option value="<?= $s ?>" <?= ($editTask['status']??'pending')===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-group" style="margin-bottom:.75rem">
        <label>Description</label>
        <textarea name="description" rows="2" placeholder="Details..."><?= e($editTask['description']??'') ?></textarea>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Due Date</label><input type="date" name="due_date" value="<?= e($editTask['due_date']??'') ?>"></div>
        <div class="form-group"><label>Due Time</label><input type="time" name="due_time" value="<?= e($editTask['due_time']??'') ?>"></div>
        <div class="form-group" style="flex:2"><label>CC Emails</label><input type="text" name="cc_emails" value="<?= e($editTask['cc_emails']??'') ?>" placeholder="a@b.com, c@d.com"></div>
      </div>

      <!-- RECURRING -->
      <div class="rec-section">
        <div style="font-weight:700;font-size:.88rem;margin-bottom:.6rem">🔁 Recurring — complete kela ki auto reopen hote</div>
        <div class="form-row" style="gap:.4rem;margin-bottom:0">
          <?php foreach(['none','daily','weekly','monthly'] as $rt): $cur=$editTask['recurring_type']??'none'; ?>
          <label class="rec-lbl <?= $cur===$rt?'on':'' ?>" id="rl_<?= $rt ?>">
            <input type="radio" name="rec" value="<?= $rt ?>" <?= $cur===$rt?'checked':'' ?> onchange="selRec('<?= $rt ?>')" style="accent-color:#00e5ff">
            <?= $rt!=='none'?$ri[$rt].' ':'' ?><?= $rl[$rt] ?>
          </label>
          <?php endforeach; ?>
        </div>
        <div id="recNote" style="font-size:.75rem;color:#00e5ff;margin-top:.45rem;<?= (!empty($editTask['recurring_type'])&&$editTask['recurring_type']!=='none')?'':'display:none' ?>">
          ✅ Complete kela ki next occurrence auto-create hote
        </div>
      </div>

      <div class="rem-row" style="margin-top:.875rem">
        <label class="chk-lbl"><input type="checkbox" name="er" <?= ($editTask['email_reminder']??1)?'checked':'' ?>> 📧 Email</label>
        <label class="chk-lbl"><input type="checkbox" name="wr" <?= ($editTask['whatsapp_reminder']??1)?'checked':'' ?>> 📱 WhatsApp</label>
        <label class="chk-lbl"><input type="checkbox" name="pr" <?= ($editTask['push_reminder']??1)?'checked':'' ?>> 🔔 Push</label>
      </div>
      <div style="display:flex;gap:.65rem;margin-top:.875rem">
        <button type="submit" class="btn btn-p"><?= $editTask?'Update →':'Add Task →' ?></button>
        <a href="tasks.php" class="btn btn-s">Cancel</a>
      </div>
    </form>
  </div>

  <!-- FILTERS -->
  <form method="GET" class="filters">
    <input type="text" name="q" value="<?= e($sq) ?>" placeholder="🔍 Search...">
    <select name="status" onchange="this.form.submit()">
      <option value="">All Status</option>
      <?php foreach(['pending','in_progress','completed'] as $s): ?>
      <option value="<?= $s ?>" <?= $fs===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="priority" onchange="this.form.submit()">
      <option value="">All Priority</option>
      <?php foreach(['high','medium','low'] as $p): ?>
      <option value="<?= $p ?>" <?= $fp===$p?'selected':'' ?>><?= ucfirst($p) ?></option>
      <?php endforeach; ?>
    </select>
    <select name="rec" onchange="this.form.submit()">
      <option value="">All Types</option>
      <option value="daily"   <?= $fr==='daily'  ?'selected':'' ?>>🔁 Daily</option>
      <option value="weekly"  <?= $fr==='weekly' ?'selected':'' ?>>📅 Weekly</option>
      <option value="monthly" <?= $fr==='monthly'?'selected':'' ?>>🗓️ Monthly</option>
    </select>
    <button type="submit" class="btn btn-s">Filter</button>
    <a href="tasks.php" class="btn btn-s">Clear</a>
  </form>

  <!-- TABLE -->
  <div class="card" style="overflow:auto">
    <?php if (!$tasks): ?><p class="empty">Task nahi. <a href="#" onclick="tf()">Add kara!</a></p>
    <?php else: ?>
    <table class="table">
      <thead><tr><th>Task</th><th>Priority</th><th>Status</th><th>Due</th><th>Repeat</th><th>Actions</th></tr></thead>
      <tbody>
      <?php foreach ($tasks as $t):
        $ov=$t['due_date']&&$t['due_date']<date('Y-m-d')&&$t['status']!=='completed';
        $isR=!empty($t['recurring_type'])&&$t['recurring_type']!=='none';
      ?>
      <tr class="<?= $ov?'row-danger':'' ?>">
        <td>
          <div style="display:flex;align-items:center;gap:.4rem;flex-wrap:wrap">
            <strong><?= e($t['title']) ?></strong>
            <?php if ($isR): ?><span class="rec-badge"><?= $ri[$t['recurring_type']] ?> <?= $t['recurring_type'] ?></span><?php endif; ?>
          </div>
          <?php if ($t['description']): ?><div class="t-desc"><?= e(mb_substr($t['description'],0,60)) ?><?= mb_strlen($t['description'])>60?'…':'' ?></div><?php endif; ?>
          <?php if (!empty($t['recurring_parent_id'])): ?><div style="font-size:.7rem;color:#5a5a72">🔗 Series</div><?php endif; ?>
        </td>
        <td><span class="badge b-<?= substr($t['priority'],0,1) === 'h' ? 'high' : ($t['priority'][0]==='m'?'med':'low') ?>"><?= $t['priority'] ?></span></td>
        <td><span class="badge bs-<?= $t['status'] ?>"><?= ucwords(str_replace('_',' ',$t['status'])) ?></span></td>
        <td class="<?= $ov?'td':'' ?>"><?= $t['due_date']??'—' ?><?= $t['due_time']?'<br><small class="tm">'.$t['due_time'].'</small>':'' ?></td>
        <td style="text-align:center"><?= $isR?'<span style="font-size:1.1rem">'.$ri[$t['recurring_type']].'</span>':'<span class="tm">—</span>' ?></td>
        <td style="white-space:nowrap">
          <?php if ($t['status']!=='completed'): ?>
          <a href="tasks.php?done=<?= $t['id'] ?>&csrf_token=<?= csrfToken() ?>" class="btn btn-g btn-sm" title="<?= $isR?'Complete + next auto-create':'Mark complete' ?>">✅<?= $isR?'🔁':'' ?></a>
          <?php endif; ?>
          <a href="tasks.php?edit=<?= $t['id'] ?>" class="btn btn-s btn-sm">✏️</a>
          <?php if ($isR): ?>
          <div style="position:relative;display:inline-block">
            <button class="btn btn-d btn-sm" onclick="td(<?= $t['id'] ?>,event)">🗑️▾</button>
            <div id="dm_<?= $t['id'] ?>" style="display:none;position:absolute;right:0;top:110%;background:#1c1c26;border:1px solid #25252f;border-radius:8px;z-index:99;min-width:185px;box-shadow:0 4px 20px rgba(0,0,0,.5)">
              <a href="tasks.php?delete=<?= $t['id'] ?>&csrf_token=<?= csrfToken() ?>" class="drop-item" onclick="return confirm('Sirf hi task delete?')">🗑️ Delete this only</a>
              <a href="tasks.php?delete=<?= $t['id'] ?>&all=1&csrf_token=<?= csrfToken() ?>" class="drop-item red" onclick="return confirm('Poori series delete karnar?')">⚠️ Delete all series</a>
            </div>
          </div>
          <?php else: ?>
          <a href="tasks.php?delete=<?= $t['id'] ?>&csrf_token=<?= csrfToken() ?>" class="btn btn-d btn-sm" onclick="return confirm('Delete?')">🗑️</a>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>
<script>
function tf(){document.getElementById('tForm').classList.toggle('hidden')}
function selRec(v){['none','daily','weekly','monthly'].forEach(x=>document.getElementById('rl_'+x).classList.toggle('on',x===v));document.getElementById('recNote').style.display=v!=='none'?'block':'none'}
function td(id,e){e.stopPropagation();document.querySelectorAll('[id^="dm_"]').forEach(m=>{if(m.id!=='dm_'+id)m.style.display='none'});const m=document.getElementById('dm_'+id);m.style.display=m.style.display==='none'?'block':'none'}
document.addEventListener('click',()=>document.querySelectorAll('[id^="dm_"]').forEach(m=>m.style.display='none'));
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.alert').forEach(a=>setTimeout(()=>{a.style.opacity='0';setTimeout(()=>a.remove(),400)},4000))});
</script>
</body>
</html>
