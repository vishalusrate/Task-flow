<?php $pg = basename($_SERVER['PHP_SELF']); ?>
<nav class="navbar">
  <div class="nav-brand">
    <a href="dashboard.php">
      <div class="logo-sm">TF</div>
      <span>TaskFlow <strong>Pro</strong></span>
    </a>
  </div>
  <div class="nav-links" id="navLinks">
    <a href="dashboard.php"  class="<?= $pg==='dashboard.php'?'active':'' ?>">🏠 Dashboard</a>
    <a href="tasks.php"      class="<?= $pg==='tasks.php'?'active':'' ?>">📋 Tasks</a>
    <a href="expenses.php"   class="<?= $pg==='expenses.php'?'active':'' ?>">💸 Expenses</a>
    <a href="dues.php"       class="<?= $pg==='dues.php'?'active':'' ?>">💰 Dues</a>
    <?php if(($_SESSION['user_role']??'')==='admin'): ?>
    <a href="../admin/index.php">⚙️ Admin</a>
    <?php endif; ?>
  </div>
  <div class="nav-user">
    <span>👤 <?= e(currentUser()['name'] ?? '') ?></span>
    <a href="../logout.php" class="btn btn-d btn-sm">Logout</a>
  </div>
  <button class="nav-toggle" onclick="document.getElementById('navLinks').classList.toggle('open')">☰</button>
</nav>
