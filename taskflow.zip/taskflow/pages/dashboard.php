<?php
require_once '../config.php';
requireLogin();
$db   = getDB();
$uid  = uid();
$user = currentUser();
$sym  = $user['currency_symbol'] ?? '₹';

$q = fn($sql,$p=[]) => call_user_func(function($db,$sql,$p){ $s=$db->prepare($sql);$s->execute($p);return $s; }, $db,$sql,$p);

$totalT    = $q("SELECT COUNT(*) FROM tasks WHERE user_id=?",[$uid])->fetchColumn();
$pendingT  = $q("SELECT COUNT(*) FROM tasks WHERE user_id=? AND status='pending'",[$uid])->fetchColumn();
$doneT     = $q("SELECT COUNT(*) FROM tasks WHERE user_id=? AND status='completed'",[$uid])->fetchColumn();
$overdueT  = $q("SELECT COUNT(*) FROM tasks WHERE user_id=? AND status!='completed' AND due_date < CURDATE()",[$uid])->fetchColumn();
$monthExp  = $q("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND MONTH(expense_date)=MONTH(NOW()) AND YEAR(expense_date)=YEAR(NOW())",[$uid])->fetchColumn();
$totalExp  = $q("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=?",[$uid])->fetchColumn();
$toGet     = $q("SELECT COALESCE(SUM(amount-paid_amount),0) FROM dues WHERE user_id=? AND due_type='given' AND status!='paid'",[$uid])->fetchColumn();
$toGive    = $q("SELECT COALESCE(SUM(amount-paid_amount),0) FROM dues WHERE user_id=? AND due_type='taken' AND status!='paid'",[$uid])->fetchColumn();

$recentT   = $q("SELECT * FROM tasks WHERE user_id=? ORDER BY created_at DESC LIMIT 6",[$uid])->fetchAll();
$upcomingD = $q("SELECT * FROM dues WHERE user_id=? AND status!='paid' ORDER BY due_date ASC LIMIT 5",[$uid])->fetchAll();

$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard — TaskFlow Pro</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'partials/navbar.php'; ?>
<div class="container">
  <?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
  <div class="page-header">
    <h2>👋 Welcome, <?= e($user['name']) ?></h2>
    <span class="tm"><?= date('l, d F Y') ?></span>
  </div>

  <div class="stats-grid">
    <div class="stat-card"><div class="stat-icon">📋</div><div class="stat-val"><?= $totalT ?></div><div class="stat-label">Total Tasks</div></div>
    <div class="stat-card w"><div class="stat-icon">⏳</div><div class="stat-val"><?= $pendingT ?></div><div class="stat-label">Pending</div></div>
    <div class="stat-card s"><div class="stat-icon">✅</div><div class="stat-val"><?= $doneT ?></div><div class="stat-label">Completed</div></div>
    <div class="stat-card d"><div class="stat-icon">🔥</div><div class="stat-val"><?= $overdueT ?></div><div class="stat-label">Overdue</div></div>
    <div class="stat-card"><div class="stat-icon">💸</div><div class="stat-val"><?= $sym.number_format($monthExp,0) ?></div><div class="stat-label">This Month Expense</div></div>
    <div class="stat-card"><div class="stat-icon">📊</div><div class="stat-val"><?= $sym.number_format($totalExp,0) ?></div><div class="stat-label">Total Expenses</div></div>
    <div class="stat-card s"><div class="stat-icon">💰</div><div class="stat-val"><?= $sym.number_format($toGet,0) ?></div><div class="stat-label">Milayche (Receive)</div></div>
    <div class="stat-card d"><div class="stat-icon">🧾</div><div class="stat-val"><?= $sym.number_format($toGive,0) ?></div><div class="stat-label">Denyache (You Owe)</div></div>
  </div>

  <div class="two-col">
    <div class="card">
      <div class="card-header"><h3>📋 Recent Tasks</h3><a href="tasks.php" class="btn btn-s btn-sm">All →</a></div>
      <div class="task-list">
        <?php if (!$recentT): ?><p class="empty">Koi task nahi. <a href="tasks.php">Add kara!</a></p><?php endif; ?>
        <?php foreach ($recentT as $t): ?>
        <div class="task-item">
          <div class="t-dot <?= $t['status'] ?>"></div>
          <div class="t-info">
            <div class="t-title"><?= e($t['title']) ?>
              <?php if (!empty($t['recurring_type']) && $t['recurring_type']!=='none'): ?>
                <span class="rec-badge">🔁 <?= $t['recurring_type'] ?></span>
              <?php endif; ?>
            </div>
            <div class="t-meta">
              <span class="badge b-<?= $t['priority'][0] ?>ed" style="font-size:.65rem"><?= $t['priority'] ?></span>
              <?php if ($t['due_date']): ?>
                <span class="<?= $t['due_date']<date('Y-m-d')&&$t['status']!=='completed'?'td':'tm' ?>" style="font-size:.75rem">📅 <?= $t['due_date'] ?></span>
              <?php endif; ?>
            </div>
          </div>
          <a href="tasks.php?edit=<?= $t['id'] ?>" class="btn btn-s btn-sm">✏️</a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h3>💰 Upcoming Dues</h3><a href="dues.php" class="btn btn-s btn-sm">All →</a></div>
      <div class="task-list">
        <?php if (!$upcomingD): ?><p class="empty">Koi due nahi. <a href="dues.php">Add kara!</a></p><?php endif; ?>
        <?php foreach ($upcomingD as $d): $rem = $d['amount']-$d['paid_amount']; ?>
        <div class="task-item">
          <div class="av" style="width:30px;height:30px;font-size:.85rem;flex-shrink:0"><?= strtoupper($d['person_name'][0]) ?></div>
          <div class="t-info">
            <div class="t-title"><?= e($d['person_name']) ?>
              <span class="badge <?= $d['due_type']==='given'?'b-ok':'b-ng' ?>" style="font-size:.6rem">
                <?= $d['due_type']==='given'?'Receive':'Owe' ?>
              </span>
            </div>
            <div class="t-meta">
              <strong><?= $sym.number_format($rem,2) ?></strong>
              <?php if ($d['due_date']): ?><span class="tm" style="font-size:.75rem">📅 <?= $d['due_date'] ?></span><?php endif; ?>
            </div>
          </div>
          <a href="dues.php?edit=<?= $d['id'] ?>" class="btn btn-s btn-sm">✏️</a>
        </div>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</div>
<script>
document.addEventListener('DOMContentLoaded',()=>{
  const alerts=document.querySelectorAll('.alert');
  alerts.forEach(a=>setTimeout(()=>{a.style.opacity='0';setTimeout(()=>a.remove(),400)},4000));
});
</script>
</body>
</html>
