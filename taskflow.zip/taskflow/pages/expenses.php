<?php
require_once '../config.php';
requireLogin();
$db=$db??getDB(); $db=getDB();
$uid=uid(); $user=currentUser(); $sym=$user['currency_symbol']??'₹';

if(isset($_GET['delete'])){verifyCsrf();$db->prepare("DELETE FROM expenses WHERE id=? AND user_id=?")->execute([(int)$_GET['delete'],$uid]);flash('success','Deleted.');header('Location: expenses.php');exit;}

if(isset($_GET['lookup'])){
    header('Content-Type: application/json');
    $s=$db->prepare("SELECT name,email,phone,whatsapp FROM users WHERE email=? AND id!=? AND is_verified=1");
    $s->execute([sanitize($_GET['lookup']),$uid]);
    echo json_encode($s->fetch()?:null);exit;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    verifyCsrf();
    $id=(int)($_POST['id']??0);$tit=sanitize($_POST['title']??'');$amt=(float)($_POST['amount']??0);
    $cat=sanitize($_POST['category']??'');$dat=$_POST['expense_date']?:date('Y-m-d');$nts=sanitize($_POST['notes']??'');
    $pn=sanitize($_POST['person_name']??'');$pe=sanitize($_POST['person_email']??'');
    $pp=sanitize($_POST['person_phone']??'');$pw=sanitize($_POST['person_whatsapp']??'');
    $sn=isset($_POST['sn'])?1:0;
    if(!$tit||$amt<=0){$error='Title aur amount required.';} elseif($id){
        $db->prepare("UPDATE expenses SET title=?,amount=?,category=?,expense_date=?,notes=?,person_name=?,person_email=?,person_phone=?,person_whatsapp=?,send_notification=? WHERE id=? AND user_id=?")
           ->execute([$tit,$amt,$cat,$dat,$nts,$pn,$pe,$pp,$pw,$sn,$id,$uid]);
        flash('success','Updated!');header('Location: expenses.php');exit;
    } else {
        $db->prepare("INSERT INTO expenses(user_id,title,amount,category,expense_date,notes,person_name,person_email,person_phone,person_whatsapp,send_notification) VALUES(?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$uid,$tit,$amt,$cat,$dat,$nts,$pn,$pe,$pp,$pw,$sn]);
        $eid=(int)$db->lastInsertId();
        if($sn&&($pe||$pw)){
            if(file_exists('../vendor/autoload.php')){
                require_once '../includes/mailer.php';require_once '../includes/notifier.php';
                $exp=['id'=>$eid,'title'=>$tit,'amount'=>$amt,'category'=>$cat,'expense_date'=>$dat,'notes'=>$nts];
                $rn=null;if($pe){$s=$db->prepare("SELECT * FROM users WHERE email=? AND is_verified=1");$s->execute([$pe]);$rn=$s->fetch();}
                if($pe){$ok=sendExpenseNotificationEmail($pe,$pn?:($rn['name']??''),$user,$exp);$db->prepare("INSERT INTO notifications(user_id,type,ref_id,channel,message,status)VALUES(?,?,?,?,?,?)")->execute([$uid,'expense',$eid,'email',$tit,$ok?'sent':'failed']);}
                $wan=$pw?:($rn['whatsapp']??'');
                if($wan){$ok=sendExpenseWhatsApp($wan,$pn?:($rn['name']??''),$user,$exp);$db->prepare("INSERT INTO notifications(user_id,type,ref_id,channel,message,status)VALUES(?,?,?,?,?,?)")->execute([$uid,'expense',$eid,'whatsapp',$tit,$ok?'sent':'failed']);}
            }
        }
        flash('success','Expense added'.($sn?' & notification sent!':'!'));header('Location: expenses.php');exit;
    }
}

$editExp=null;if(isset($_GET['edit'])){$s=$db->prepare("SELECT * FROM expenses WHERE id=? AND user_id=?");$s->execute([(int)$_GET['edit'],$uid]);$editExp=$s->fetch();}

$mon=$_GET['month']??date('Y-m');
$tM=$db->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND DATE_FORMAT(expense_date,'%Y-%m')=?");$tM->execute([$uid,$mon]);
$tA=$db->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=?");$tA->execute([$uid]);
$cB=$db->prepare("SELECT category,SUM(amount)t FROM expenses WHERE user_id=? AND MONTH(expense_date)=MONTH(NOW()) GROUP BY category ORDER BY t DESC LIMIT 4");$cB->execute([$uid]);
$stmt=$db->prepare("SELECT * FROM expenses WHERE user_id=? AND DATE_FORMAT(expense_date,'%Y-%m')=? ORDER BY expense_date DESC");$stmt->execute([$uid,$mon]);$exps=$stmt->fetchAll();
$cats=['Food','Transport','Shopping','Bills','Medical','Education','Entertainment','Salary','Business','Other'];
$ru=$db->prepare("SELECT name,email FROM users WHERE id!=? AND is_verified=1 ORDER BY name");$ru->execute([$uid]);$ruList=$ru->fetchAll();
$flash=getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Expenses — TaskFlow Pro</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'partials/navbar.php'; ?>
<div class="container">
  <?php if ($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
  <?php if (!empty($error)): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <div class="page-header"><h2>💸 Expenses</h2><button class="btn btn-p" onclick="ef()">+ Add</button></div>

  <div class="stats-grid" style="grid-template-columns:repeat(auto-fill,minmax(160px,1fr))">
    <div class="stat-card"><div class="stat-icon">📅</div><div class="stat-val"><?= $sym.number_format($tM->fetchColumn(),2) ?></div><div class="stat-label">This Month</div></div>
    <div class="stat-card"><div class="stat-icon">📊</div><div class="stat-val"><?= $sym.number_format($tA->fetchColumn(),2) ?></div><div class="stat-label">All Time</div></div>
    <?php foreach($cB->fetchAll() as $c): ?><div class="stat-card"><div class="stat-icon">🏷️</div><div class="stat-val"><?= $sym.number_format($c['t'],0) ?></div><div class="stat-label"><?= e($c['category']?:'Other') ?></div></div><?php endforeach; ?>
  </div>

  <div class="card form-card <?= ($editExp||!empty($error))?'':'hidden' ?>" id="eForm">
    <h3><?= $editExp?'✏️ Edit':'➕ New Expense' ?></h3>
    <form method="POST" id="expForm">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <?php if($editExp): ?><input type="hidden" name="id" value="<?= $editExp['id'] ?>"><?php endif; ?>
      <div class="form-row">
        <div class="form-group" style="flex:2"><label>Description *</label><input type="text" name="title" value="<?= e($editExp['title']??'') ?>" placeholder="Kasha sathi kharch?" required></div>
        <div class="form-group"><label>Amount (<?= $sym ?>) *</label><input type="number" step="0.01" name="amount" value="<?= e($editExp['amount']??'') ?>" placeholder="0.00" required></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Category</label><select name="category"><option value="">Select</option><?php foreach($cats as $c): ?><option value="<?= $c ?>" <?= ($editExp['category']??'')===$c?'selected':'' ?>><?= $c ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>Date</label><input type="date" name="expense_date" value="<?= e($editExp['expense_date']??date('Y-m-d')) ?>"></div>
        <div class="form-group" style="flex:2"><label>Notes</label><input type="text" name="notes" value="<?= e($editExp['notes']??'') ?>" placeholder="Optional..."></div>
      </div>

      <div style="border-top:1px solid #25252f;margin:.875rem 0;padding-top:.875rem">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:.6rem">
          <strong style="font-size:.88rem">👤 Person (Optional — notify kara)</strong>
          <label class="chk-lbl"><input type="checkbox" id="showP" <?= !empty($editExp['person_name'])?'checked':'' ?> onchange="document.getElementById('pFields').classList.toggle('hidden',!this.checked)"> Person Add</label>
        </div>
        <div id="pFields" class="<?= !empty($editExp['person_name'])?'':'hidden' ?>">
          <div class="form-row">
            <div class="form-group" style="flex:2;position:relative">
              <label>Email * <span id="foundBadge" class="badge b-ok" style="display:none">✅ Registered User</span></label>
              <input type="email" name="person_email" id="pEmail" value="<?= e($editExp['person_email']??'') ?>" placeholder="person@email.com" list="ruList" oninput="lookupUser(this.value)">
              <datalist id="ruList"><?php foreach($ruList as $r): ?><option value="<?= e($r['email']) ?>"><?= e($r['name']) ?></option><?php endforeach; ?></datalist>
            </div>
            <div class="form-group" style="flex:2"><label>Full Name *</label><input type="text" name="person_name" id="pName" value="<?= e($editExp['person_name']??'') ?>" placeholder="Ramesh, Priya..."></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>Phone</label><input type="text" name="person_phone" id="pPhone" value="<?= e($editExp['person_phone']??'') ?>" placeholder="+91 9876543210"></div>
            <div class="form-group"><label>WhatsApp</label><input type="text" name="person_whatsapp" id="pWa" value="<?= e($editExp['person_whatsapp']??'') ?>" placeholder="+91 9876543210"></div>
          </div>
          <label class="chk-lbl"><input type="checkbox" name="sn" <?= ($editExp['send_notification']??0)?'checked':'checked' ?>> 📧📱 Email + WhatsApp notification pathava</label>
        </div>
      </div>

      <div style="display:flex;gap:.65rem;margin-top:.875rem">
        <button type="submit" class="btn btn-p"><?= $editExp?'Update →':'Add Expense →' ?></button>
        <a href="expenses.php" class="btn btn-s">Cancel</a>
      </div>
    </form>
  </div>

  <form method="GET" class="filters">
    <input type="month" name="month" value="<?= e($mon) ?>" onchange="this.form.submit()">
    <button type="submit" class="btn btn-s">Filter</button>
    <a href="expenses.php" class="btn btn-s">This Month</a>
  </form>

  <div class="card" style="overflow:auto">
    <?php if (!$exps): ?><p class="empty">Koi expense nahi. <a href="#" onclick="ef()">Add kara!</a></p>
    <?php else: ?>
    <table class="table">
      <thead><tr><th>Description</th><th>Category</th><th>Date</th><th>Amount</th><th>Person</th><th>Notes</th><th>Actions</th></tr></thead>
      <tbody><?php $mt=0; ?>
      <?php foreach($exps as $ex): $mt+=$ex['amount']; ?>
      <tr>
        <td><strong><?= e($ex['title']) ?></strong></td>
        <td><?= $ex['category']?'<span class="badge b-med">'.e($ex['category']).'</span>':'—' ?></td>
        <td><?= $ex['expense_date'] ?></td>
        <td class="td"><strong><?= $sym.number_format($ex['amount'],2) ?></strong></td>
        <td>
          <?php if(!empty($ex['person_name'])): ?>
          <div style="font-size:.82rem"><strong><?= e($ex['person_name']) ?></strong>
            <?php if(!empty($ex['person_email'])): ?><br><a href="mailto:<?= e($ex['person_email']) ?>" style="font-size:.73rem">📧 <?= e($ex['person_email']) ?></a><?php endif; ?>
            <?php if(!empty($ex['person_whatsapp'])): ?><br><a href="https://wa.me/<?= preg_replace('/\D/','',$ex['person_whatsapp']) ?>" target="_blank" style="font-size:.73rem;color:#25D366">📱 WA</a><?php endif; ?>
            <?php if($ex['send_notification']): ?><br><span class="badge b-ok">Notified ✓</span><?php endif; ?>
          </div>
          <?php else: ?>—<?php endif; ?>
        </td>
        <td class="tm"><?= e($ex['notes']??'—') ?></td>
        <td>
          <a href="expenses.php?edit=<?= $ex['id'] ?>" class="btn btn-s btn-sm">✏️</a>
          <a href="expenses.php?delete=<?= $ex['id'] ?>&csrf_token=<?= csrfToken() ?>" class="btn btn-d btn-sm" onclick="return confirm('Delete?')">🗑️</a>
        </td>
      </tr>
      <?php endforeach; ?>
      <tr class="total-row"><td colspan="3"><strong>Month Total</strong></td><td colspan="4"><strong class="td"><?= $sym.number_format($mt,2) ?></strong></td></tr>
      </tbody>
    </table>
    <?php endif; ?>
  </div>
</div>
<script>
function ef(){document.getElementById('eForm').classList.toggle('hidden')}
let lt;
function lookupUser(em){
  clearTimeout(lt);if(!em||!em.includes('@')){document.getElementById('foundBadge').style.display='none';return;}
  lt=setTimeout(async()=>{
    try{const r=await fetch('expenses.php?lookup='+encodeURIComponent(em));const u=await r.json();
    const b=document.getElementById('foundBadge');
    if(u){b.style.display='inline';if(!document.getElementById('pName').value)document.getElementById('pName').value=u.name||'';if(!document.getElementById('pPhone').value)document.getElementById('pPhone').value=u.phone||'';if(!document.getElementById('pWa').value)document.getElementById('pWa').value=u.whatsapp||'';}
    else b.style.display='none';}catch(e){}
  },500);
}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.alert').forEach(a=>setTimeout(()=>{a.style.opacity='0';setTimeout(()=>a.remove(),400)},4000))});
</script>
</body>
</html>
