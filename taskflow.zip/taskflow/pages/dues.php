<?php
require_once '../config.php';
requireLogin();
$db=getDB();$uid=uid();$user=currentUser();$sym=$user['currency_symbol']??'₹';

if(isset($_GET['delete'])){verifyCsrf();$db->prepare("DELETE FROM dues WHERE id=? AND user_id=?")->execute([(int)$_GET['delete'],$uid]);flash('success','Deleted.');header('Location: dues.php');exit;}

if(isset($_GET['pay'])&&isset($_GET['amt'])){
    verifyCsrf();$did=(int)$_GET['pay'];$pa=(float)$_GET['amt'];
    $s=$db->prepare("SELECT * FROM dues WHERE id=? AND user_id=?");$s->execute([$did,$uid]);$d=$s->fetch();
    if($d){$np=min($d['paid_amount']+$pa,$d['amount']);$st=$np>=$d['amount']?'paid':($np>0?'partial':'pending');$db->prepare("UPDATE dues SET paid_amount=?,status=? WHERE id=?")->execute([$np,$st,$did]);flash('success','Payment recorded! ✅');}
    header('Location: dues.php');exit;
}

if($_SERVER['REQUEST_METHOD']==='POST'){
    verifyCsrf();
    $id=(int)($_POST['id']??0);$pn=sanitize($_POST['person_name']??'');$pp=sanitize($_POST['person_phone']??'');
    $pw=sanitize($_POST['person_whatsapp']??'');$pe=sanitize($_POST['person_email']??'');
    $amt=(float)($_POST['amount']??0);$typ=in_array($_POST['due_type'],['given','taken'])?$_POST['due_type']:'given';
    $dsc=sanitize($_POST['description']??'');$dd=$_POST['due_date']?:null;
    $wr=isset($_POST['wr'])?1:0;$er=isset($_POST['er'])?1:0;$pr=isset($_POST['pr'])?1:0;
    if(!$pn||$amt<=0){$error='Name aur amount required.';}
    elseif($id){
        $db->prepare("UPDATE dues SET person_name=?,person_phone=?,person_whatsapp=?,person_email=?,amount=?,due_type=?,description=?,due_date=?,whatsapp_reminder=?,email_reminder=?,push_reminder=? WHERE id=? AND user_id=?")
           ->execute([$pn,$pp,$pw,$pe,$amt,$typ,$dsc,$dd,$wr,$er,$pr,$id,$uid]);
        flash('success','Updated!');header('Location: dues.php');exit;
    } else {
        $db->prepare("INSERT INTO dues(user_id,person_name,person_phone,person_whatsapp,person_email,amount,due_type,description,due_date,whatsapp_reminder,email_reminder,push_reminder) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)")
           ->execute([$uid,$pn,$pp,$pw,$pe,$amt,$typ,$dsc,$dd,$wr,$er,$pr]);
        flash('success','Due added!');header('Location: dues.php');exit;
    }
}

$editDue=null;if(isset($_GET['edit'])){$s=$db->prepare("SELECT * FROM dues WHERE id=? AND user_id=?");$s->execute([(int)$_GET['edit'],$uid]);$editDue=$s->fetch();}

$tG=$db->prepare("SELECT COALESCE(SUM(amount-paid_amount),0) FROM dues WHERE user_id=? AND due_type='given' AND status!='paid'");$tG->execute([$uid]);
$tT=$db->prepare("SELECT COALESCE(SUM(amount-paid_amount),0) FROM dues WHERE user_id=? AND due_type='taken' AND status!='paid'");$tT->execute([$uid]);

$ft=$_GET['type']??'';$fs=$_GET['status']??'';
$wh="user_id=?";$pa=[$uid];
if($ft){$wh.=" AND due_type=?";$pa[]=$ft;}
if($fs){$wh.=" AND status=?";$pa[]=$fs;}
$stmt=$db->prepare("SELECT * FROM dues WHERE $wh ORDER BY FIELD(status,'pending','partial','paid'),due_date ASC");$stmt->execute($pa);$dues=$stmt->fetchAll();
$flash=getFlash();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dues — TaskFlow Pro</title>
<link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php include 'partials/navbar.php'; ?>
<div class="container">
  <?php if($flash): ?><div class="alert alert-<?= $flash['type'] ?>"><?= e($flash['msg']) ?></div><?php endif; ?>
  <?php if(!empty($error)): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <div class="page-header"><h2>💰 Dues & Udhari</h2><button class="btn btn-p" onclick="df()">+ Add Due</button></div>

  <div class="stats-grid" style="grid-template-columns:repeat(2,1fr);max-width:420px">
    <div class="stat-card s"><div class="stat-icon">📥</div><div class="stat-val"><?= $sym.number_format($tG->fetchColumn(),2) ?></div><div class="stat-label">Milayche (Receive)</div></div>
    <div class="stat-card d"><div class="stat-icon">📤</div><div class="stat-val"><?= $sym.number_format($tT->fetchColumn(),2) ?></div><div class="stat-label">Denyache (You Owe)</div></div>
  </div>

  <div class="card form-card <?= ($editDue||!empty($error))?'':'hidden' ?>" id="dForm">
    <h3><?= $editDue?'✏️ Edit Due':'➕ New Due' ?></h3>
    <form method="POST">
      <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
      <?php if($editDue): ?><input type="hidden" name="id" value="<?= $editDue['id'] ?>"><?php endif; ?>
      <div class="form-row">
        <div class="form-group" style="flex:2"><label>Person Name *</label><input type="text" name="person_name" value="<?= e($editDue['person_name']??'') ?>" placeholder="Ramesh, Priya..." required></div>
        <div class="form-group"><label>Type *</label><select name="due_type"><option value="given" <?= ($editDue['due_type']??'')==='given'?'selected':'' ?>>💰 I Gave (Milayche)</option><option value="taken" <?= ($editDue['due_type']??'')==='taken'?'selected':'' ?>>💸 I Took (Denyache)</option></select></div>
        <div class="form-group"><label>Amount (<?= $sym ?>) *</label><input type="number" step="0.01" name="amount" value="<?= e($editDue['amount']??'') ?>" placeholder="0.00" required></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Phone</label><input type="text" name="person_phone" value="<?= e($editDue['person_phone']??'') ?>" placeholder="+91..."></div>
        <div class="form-group"><label>WhatsApp</label><input type="text" name="person_whatsapp" value="<?= e($editDue['person_whatsapp']??'') ?>" placeholder="+91..."></div>
        <div class="form-group" style="flex:2"><label>Email</label><input type="email" name="person_email" value="<?= e($editDue['person_email']??'') ?>" placeholder="person@email.com"></div>
        <div class="form-group"><label>Due Date</label><input type="date" name="due_date" value="<?= e($editDue['due_date']??'') ?>"></div>
      </div>
      <div class="form-group" style="margin-bottom:.75rem"><label>Description</label><textarea name="description" rows="2" placeholder="Kasha sathi..."><?= e($editDue['description']??'') ?></textarea></div>
      <div class="rem-row">
        <label class="chk-lbl"><input type="checkbox" name="er" <?= ($editDue['email_reminder']??1)?'checked':'' ?>> 📧 Email</label>
        <label class="chk-lbl"><input type="checkbox" name="wr" <?= ($editDue['whatsapp_reminder']??1)?'checked':'' ?>> 📱 WhatsApp</label>
        <label class="chk-lbl"><input type="checkbox" name="pr" <?= ($editDue['push_reminder']??1)?'checked':'' ?>> 🔔 Push</label>
      </div>
      <div style="display:flex;gap:.65rem;margin-top:.875rem">
        <button type="submit" class="btn btn-p"><?= $editDue?'Update →':'Add Due →' ?></button>
        <a href="dues.php" class="btn btn-s">Cancel</a>
      </div>
    </form>
  </div>

  <form method="GET" class="filters">
    <select name="type" onchange="this.form.submit()"><option value="">All Types</option><option value="given" <?= $ft==='given'?'selected':'' ?>>💰 Milayche</option><option value="taken" <?= $ft==='taken'?'selected':'' ?>>💸 Denyache</option></select>
    <select name="status" onchange="this.form.submit()"><option value="">All Status</option><option value="pending" <?= $fs==='pending'?'selected':'' ?>>Pending</option><option value="partial" <?= $fs==='partial'?'selected':'' ?>>Partial</option><option value="paid" <?= $fs==='paid'?'selected':'' ?>>Paid</option></select>
    <a href="dues.php" class="btn btn-s">Clear</a>
  </form>

  <div class="dues-grid">
    <?php if(!$dues): ?><p class="empty">Koi due nahi. <a href="#" onclick="df()">Add kara!</a></p><?php endif; ?>
    <?php foreach($dues as $d): $rem=$d['amount']-$d['paid_amount'];$pct=$d['amount']>0?$d['paid_amount']/$d['amount']*100:0; ?>
    <div class="due-card <?= $d['status']==='paid'?'paid-card':'' ?>">
      <div class="due-hdr">
        <div class="av av-lg"><?= strtoupper($d['person_name'][0]) ?></div>
        <div>
          <div class="due-name"><?= e($d['person_name']) ?></div>
          <span class="badge <?= $d['due_type']==='given'?'b-ok':'b-ng' ?>"><?= $d['due_type']==='given'?'💰 Receive':'💸 Owe' ?></span>
        </div>
        <span class="badge bs-<?= $d['status'] ?>" style="margin-left:auto"><?= ucfirst($d['status']) ?></span>
      </div>
      <div class="due-amt">
        <div>Total: <strong><?= $sym.number_format($d['amount'],2) ?></strong></div>
        <div>Paid: <span class="tc"><?= $sym.number_format($d['paid_amount'],2) ?></span></div>
        <div>Baki: <strong class="td"><?= $sym.number_format($rem,2) ?></strong></div>
      </div>
      <div class="pb-wrap"><div class="pb" style="width:<?= $pct ?>%;background:<?= $pct>=100?'#00c48c':'#ff6b35' ?>"></div></div>
      <?php if($d['due_date']): ?><div class="tm" style="font-size:.78rem;margin:.2rem 0">📅 <?= $d['due_date'] ?></div><?php endif; ?>
      <?php if($d['description']): ?><div class="tm" style="font-size:.78rem"><?= e($d['description']) ?></div><?php endif; ?>
      <div class="due-contacts">
        <?php if($d['person_phone']): ?><span>📞 <?= e($d['person_phone']) ?></span><?php endif; ?>
        <?php if($d['person_whatsapp']): ?><a href="https://wa.me/<?= preg_replace('/\D/','',$d['person_whatsapp']) ?>" target="_blank" style="color:#25D366">📱 WhatsApp</a><?php endif; ?>
        <?php if($d['person_email']): ?><a href="mailto:<?= e($d['person_email']) ?>">📧 Mail</a><?php endif; ?>
      </div>
      <?php if($d['status']!=='paid'): ?>
      <form method="GET" style="display:flex;gap:.4rem;align-items:center;margin-top:.6rem">
        <input type="hidden" name="pay" value="<?= $d['id'] ?>">
        <input type="hidden" name="csrf_token" value="<?= csrfToken() ?>">
        <input type="number" name="amt" step="0.01" placeholder="Amount" class="inline-input">
        <button type="submit" class="btn btn-p btn-sm">Record Payment</button>
      </form>
      <?php endif; ?>
      <div style="margin-top:.65rem;display:flex;gap:.4rem">
        <a href="dues.php?edit=<?= $d['id'] ?>" class="btn btn-s btn-sm">✏️ Edit</a>
        <a href="dues.php?delete=<?= $d['id'] ?>&csrf_token=<?= csrfToken() ?>" class="btn btn-d btn-sm" onclick="return confirm('Delete?')">🗑️</a>
      </div>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<script>
function df(){document.getElementById('dForm').classList.toggle('hidden')}
document.addEventListener('DOMContentLoaded',()=>{document.querySelectorAll('.alert').forEach(a=>setTimeout(()=>{a.style.opacity='0';setTimeout(()=>a.remove(),400)},4000))});
</script>
</body>
</html>
