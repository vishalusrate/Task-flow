<?php
require_once __DIR__ . '/../config.php';

function sendWhatsApp(string $to, string $msg): bool {
    $to = preg_replace('/[^0-9+]/','',$to);
    if (!str_starts_with($to,'+')) $to = '+91'.$to;
    $url = 'https://api.twilio.com/2010-04-01/Accounts/'.TWILIO_SID.'/Messages.json';
    $ch = curl_init($url);
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_POST=>true,
        CURLOPT_POSTFIELDS=>http_build_query(['From'=>TWILIO_WHATSAPP,'To'=>'whatsapp:'.$to,'Body'=>$msg]),
        CURLOPT_USERPWD=>TWILIO_SID.':'.TWILIO_TOKEN]);
    $res=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_HTTP_CODE);curl_close($ch);
    if($code>=200&&$code<300){return true;}
    error_log('WhatsApp error: '.$res);return false;
}

function sendTaskWhatsApp(array $user, array $task): bool {
    if (empty($user['whatsapp'])) return false;
    $m ="🚀 *TaskFlow Pro Reminder*\n\n";
    $m.="📌 *Task:* ".$task['title']."\n";
    $m.="🔥 *Priority:* ".strtoupper($task['priority'])."\n";
    $m.="📅 *Due:* ".($task['due_date']??'')." ".($task['due_time']??'')."\n";
    $m.="📊 *Status:* ".ucfirst($task['status'])."\n";
    if(!empty($task['description'])) $m.="📝 ".$task['description']."\n";
    $m.="\n🔗 ".APP_URL."/pages/tasks.php";
    return sendWhatsApp($user['whatsapp'],$m);
}

function sendDueWhatsApp(array $user, array $due): bool {
    if (empty($user['whatsapp'])) return false;
    $sym=$user['currency_symbol']??'₹'; $rem=$due['amount']-$due['paid_amount'];
    $type=$due['due_type']==='given'?'RECEIVE':'OWE';
    $m ="💰 *TaskFlow Pro - Due Reminder*\n\n";
    $m.="👤 *Person:* ".$due['person_name']."\n";
    $m.="💸 *Type:* You should ".$type."\n";
    $m.="💵 *Total:* ".$sym.number_format($due['amount'],2)."\n";
    $m.="⚠️ *Baki:* ".$sym.number_format($rem,2)."\n";
    if(!empty($due['due_date'])) $m.="📅 *Due:* ".$due['due_date']."\n";
    $m.="\n🔗 ".APP_URL."/pages/dues.php";
    return sendWhatsApp($user['whatsapp'],$m);
}

function sendDueWhatsAppToPerson(array $due, string $creditorName): bool {
    if (empty($due['person_whatsapp'])) return false;
    $rem=$due['amount']-$due['paid_amount'];
    $m ="💰 *Payment Reminder*\n\n";
    $m.="Hi ".$due['person_name']."! 👋\n";
    $m.="*".$creditorName."* kadun reminder:\n\n";
    $m.="⚠️ *Amount Due:* ₹".number_format($rem,2)."\n";
    if(!empty($due['due_date'])) $m.="📅 *Due Date:* ".$due['due_date']."\n";
    if(!empty($due['description'])) $m.="📝 ".$due['description']."\n";
    $m.="\nLavkar settle kara. Dhanyavad! 🙏";
    return sendWhatsApp($due['person_whatsapp'],$m);
}

function sendExpenseWhatsApp(string $to, string $name, array $sender, array $exp): bool {
    if (empty($to)) return false;
    $sym=$sender['currency_symbol']??'₹';
    $m ="💸 *Expense Notification*\n\n";
    $m.="Hi ".$name."! 👋\n";
    $m.="*".$sender['name']."* ne expense add keli:\n\n";
    $m.="📌 *Description:* ".$exp['title']."\n";
    $m.="💰 *Amount:* ".$sym.number_format($exp['amount'],2)."\n";
    if(!empty($exp['category'])) $m.="🏷️ *Category:* ".$exp['category']."\n";
    $m.="📅 *Date:* ".$exp['expense_date']."\n";
    if(!empty($exp['notes'])) $m.="📝 ".$exp['notes']."\n";
    $m.="\n_Sent via TaskFlow Pro_";
    return sendWhatsApp($to,$m);
}

function sendPushNotification(string $sub_json, string $title, string $body, string $url=''): bool {
    if (!file_exists(__DIR__.'/../vendor/autoload.php')) return false;
    require_once __DIR__.'/../vendor/autoload.php';
    if (!class_exists('Minishlink\WebPush\WebPush')) return false;
    try {
        $auth=['VAPID'=>['subject'=>VAPID_SUBJECT,'publicKey'=>VAPID_PUBLIC_KEY,'privateKey'=>VAPID_PRIVATE_KEY]];
        $wp=new \Minishlink\WebPush\WebPush($auth);
        $sub=\Minishlink\WebPush\Subscription::create(json_decode($sub_json,true));
        $wp->queueNotification($sub,json_encode(['title'=>$title,'body'=>$body,'url'=>$url]));
        foreach($wp->flush() as $r) if(!$r->isSuccess()) return false;
        return true;
    } catch(Exception $e){ error_log('Push: '.$e->getMessage()); return false; }
}

function sendTaskPush(array $user, array $task): bool {
    if(empty($user['push_subscription'])) return false;
    return sendPushNotification($user['push_subscription'],'⏰ '.$task['title'],'Due: '.($task['due_date']??''),APP_URL.'/pages/tasks.php');
}

function sendDuePush(array $user, array $due): bool {
    if(empty($user['push_subscription'])) return false;
    $rem=$due['amount']-$due['paid_amount'];
    return sendPushNotification($user['push_subscription'],'💰 '.$due['person_name'],'Baki: '.($user['currency_symbol']??'₹').number_format($rem,2),APP_URL.'/pages/dues.php');
}
