<?php
// mailer.php — works WITHOUT composer if mail not configured
// With composer: composer require phpmailer/phpmailer

require_once __DIR__ . '/../config.php';

function sendMail(string $to, string $name, string $subject, string $body, array $cc=[]): bool {
    if (!file_exists(__DIR__.'/../vendor/autoload.php')) return false;
    require_once __DIR__ . '/../vendor/autoload.php';
    if (!class_exists('PHPMailer\PHPMailer\PHPMailer')) return false;
    $m = new \PHPMailer\PHPMailer\PHPMailer(true);
    try {
        $m->isSMTP(); $m->Host=MAIL_HOST; $m->SMTPAuth=true;
        $m->Username=MAIL_USERNAME; $m->Password=MAIL_PASSWORD;
        $m->SMTPSecure='tls'; $m->Port=MAIL_PORT; $m->CharSet='UTF-8';
        $m->setFrom(MAIL_FROM_EMAIL, MAIL_FROM_NAME);
        $m->addAddress($to, $name);
        foreach($cc as $c) if(filter_var(trim($c),FILTER_VALIDATE_EMAIL)) $m->addCC(trim($c));
        $m->isHTML(true); $m->Subject=$subject;
        $m->Body=mailTemplate($subject,$body); $m->AltBody=strip_tags($body);
        $m->send(); return true;
    } catch(Exception $e) { error_log('Mail: '.$m->ErrorInfo); return false; }
}

function mailTemplate(string $title, string $body): string {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>
body{margin:0;font-family:Arial,sans-serif;background:#0d0d0d}
.w{max-width:600px;margin:0 auto;background:#161616;border-radius:12px;overflow:hidden}
.h{background:linear-gradient(135deg,#ff6b35,#ff8c42);padding:1.75rem;text-align:center}
.h h1{color:#fff;margin:0;font-size:1.4rem}
.b{padding:1.75rem;color:#e8e8e8;line-height:1.6}
.f{padding:.875rem 1.75rem;text-align:center;color:#555;font-size:.75rem;border-top:1px solid #222}
.btn{display:inline-block;background:#ff6b35;color:#fff;padding:.7rem 1.4rem;border-radius:8px;text-decoration:none;font-weight:bold;margin-top:1rem}
</style></head><body><div class="w">
<div class="h"><h1>🚀 TaskFlow Pro</h1></div>
<div class="b"><h2>'.htmlspecialchars($title).'</h2>'.$body.'</div>
<div class="f">TaskFlow Pro &copy; '.date('Y').' · Auto sent</div>
</div></body></html>';
}

function sendVerificationEmail(string $email, string $name, string $token): bool {
    $link = APP_URL.'/verify.php?token='.urlencode($token);
    $b = '<p>Hi <strong>'.htmlspecialchars($name).'</strong>,</p>
    <p>TaskFlow Pro madhe swagat! Email verify kara:</p>
    <a href="'.$link.'" class="btn">✅ Verify Email</a>
    <p style="margin-top:1rem;color:#888;font-size:.85rem">24 tastashin valid ahe.</p>';
    return sendMail($email, $name, 'TaskFlow Pro — Email Verify Kara', $b);
}

function sendTaskReminderEmail(array $user, array $task): bool {
    $cc = !empty($task['cc_emails']) ? explode(',', $task['cc_emails']) : [];
    $b = '<p>Hi <strong>'.htmlspecialchars($user['name']).'</strong>,</p>
    <p>Task reminder:</p>
    <table style="width:100%;border-collapse:collapse;margin:1rem 0">
      <tr><td style="padding:7px;color:#aaa">Task</td><td style="padding:7px;font-weight:bold">'.htmlspecialchars($task['title']).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Priority</td><td style="padding:7px">'.strtoupper($task['priority']).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Due</td><td style="padding:7px;color:#ff6b35">'.($task['due_date']??'').' '.($task['due_time']??'').'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Status</td><td style="padding:7px">'.htmlspecialchars($task['status']).'</td></tr>
    </table>
    <a href="'.APP_URL.'/pages/tasks.php" class="btn">View Task</a>';
    return sendMail($user['email'], $user['name'], '⏰ Task Reminder: '.$task['title'], $b, $cc);
}

function sendDueReminderEmail(array $user, array $due): bool {
    $sym=$user['currency_symbol']??'₹'; $rem=$due['amount']-$due['paid_amount'];
    $b = '<p>Hi <strong>'.htmlspecialchars($user['name']).'</strong>,</p>
    <p>Due reminder:</p>
    <table style="width:100%;border-collapse:collapse;margin:1rem 0">
      <tr><td style="padding:7px;color:#aaa">Person</td><td style="padding:7px;font-weight:bold">'.htmlspecialchars($due['person_name']).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Total</td><td style="padding:7px">'.$sym.number_format($due['amount'],2).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Baki</td><td style="padding:7px;color:#ff6b35;font-weight:bold">'.$sym.number_format($rem,2).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Due Date</td><td style="padding:7px">'.($due['due_date']??'N/A').'</td></tr>
    </table>
    <a href="'.APP_URL.'/pages/dues.php" class="btn">View Dues</a>';
    return sendMail($user['email'], $user['name'], '💰 Due Reminder: '.$due['person_name'], $b);
}

function sendExpenseNotificationEmail(string $to, string $name, array $sender, array $exp): bool {
    $sym=$sender['currency_symbol']??'₹';
    $b = '<p>Hi <strong>'.htmlspecialchars($name).'</strong>,</p>
    <p><strong>'.htmlspecialchars($sender['name']).'</strong> ne ek expense add keli:</p>
    <table style="width:100%;border-collapse:collapse;margin:1rem 0">
      <tr><td style="padding:7px;color:#aaa">Description</td><td style="padding:7px;font-weight:bold">'.htmlspecialchars($exp['title']).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Amount</td><td style="padding:7px;color:#ff6b35;font-weight:bold">'.$sym.number_format($exp['amount'],2).'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Category</td><td style="padding:7px">'.htmlspecialchars($exp['category']??'N/A').'</td></tr>
      <tr><td style="padding:7px;color:#aaa">Date</td><td style="padding:7px">'.htmlspecialchars($exp['expense_date']).'</td></tr>
      '.($exp['notes']?'<tr><td style="padding:7px;color:#aaa">Notes</td><td style="padding:7px">'.htmlspecialchars($exp['notes']).'</td></tr>':'').'
    </table>';
    return sendMail($to, $name, '💸 Expense Notification from '.$sender['name'], $b);
}
